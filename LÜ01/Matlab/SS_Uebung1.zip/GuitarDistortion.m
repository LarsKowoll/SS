function [y] = GuitarDistortion(x, Typ, D)
%UNTITLED Summary of this function goes here
%   x = Eingangssignal
%   Typ = Distortion-Typ 0 f�r Tangens Hyperbolicus, 1 nach Bendisken
%   D = Distortionstaerk

FileSize = size(x,1);
y = zeros(FileSize,0);

    if Typ == 0
        y = tanh(D*x);
    elseif Typ == 1
        z = D*x;
        y = -sign(-z) .* (1-exp(sign(-z).*z));
    end
end

